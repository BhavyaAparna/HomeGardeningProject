import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactGardenerComponent } from './contact-gardener.component';

describe('ContactGardenerComponent', () => {
  let component: ContactGardenerComponent;
  let fixture: ComponentFixture<ContactGardenerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactGardenerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactGardenerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
