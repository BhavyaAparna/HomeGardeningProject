import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-gardener',
  templateUrl: './contact-gardener.component.html',
  styleUrls: ['./contact-gardener.component.css']
})
export class ContactGardenerComponent implements OnInit {

  gardeners: any;
  constructor(private service: UserService,private router: Router) { }

  ngOnInit(): void {
    this.service.getAllGardeners().subscribe( (result: any) => {console.log(result); this.gardeners = result; });
  } 
  contact(){
    this.router.navigate(['booking']);
  }
}
