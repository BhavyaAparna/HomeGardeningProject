import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  cartItems = [];
  itemToBeAdded: Subject<any>;
  private isUserLogged: any;
  constructor(private httpClient: HttpClient) { 
    this.isUserLogged = false;
    this.itemToBeAdded = new Subject();
  }
  setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
   registerUser(user: any) {
     alert("Successfully Registered");
    return this.httpClient.post('RESTAPI_HomeGardening/webapi/myresource/registerUser/',  user);
  }
  
  getUserByPass(userEmail:any,userPassword:any):any{
    return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/getUserByPass/'+userEmail +'/'+userPassword);
  }

  registerGardener(gardener: any) {
    alert("Successfully Registered");
   return this.httpClient.post('RESTAPI_HomeGardening/webapi/myresource/registerGardener/',  gardener);
 }
 getGardenerByUserPass(gardenerEmail:any,gardenerPassword:any):any{
   return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/getGardenerByUserPass/'+gardenerEmail +'/'+gardenerPassword);
 }
  
  /*addToCart(product: any) {
    this.itemToBeAdded.next(product);
    this.cartItems.push(product);
    // localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }*/
  getForCart() {
    return this.itemToBeAdded.asObservable();
  }

  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('itemImage', fileToUpload, fileToUpload.name);
    formData.append('itemName', ImageForm.itemName);
    formData.append('itemDescription', ImageForm.itemDescription);
    return this.httpClient.post('RESTAPI_HomeGardening/webapi/myresource/uploadImage', formData);
  }
  postFile1(VideoForm: any, fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('itemVideo', fileToUpload,fileToUpload.name);
    formData.append('itemName', VideoForm.itemName);
    formData.append('itemDescription', VideoForm.itemDescription);
    return this.httpClient.post('RESTAPI_HomeGardening/webapi/myresource/uploadVideo', formData);
  }
  /*getImage(): Observable<File> {
    console.log('Inside Service...');
    return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/downloadImage', { responseType: 'blob' });
 }*/
 getItems() {
  return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/getItems').pipe(retry(10));
 }

 getItemVideos() {
  return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/getItemVideos').pipe(retry(10));
 }
 getAllGardeners(){
   return this.httpClient.get('RESTAPI_HomeGardening/webapi/myresource/getAllGardeners');
 }

}
  

