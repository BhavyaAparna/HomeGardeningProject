import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
@Component({
  selector: 'app-show-image',
  templateUrl: './show-image.component.html',
  styleUrls: ['./show-image.component.css']
})
export class ShowImageComponent implements OnInit {
  items: any;
  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.service.getItems().subscribe( (result: any) => {console.log(result); this.items = result; });
  } 

}
