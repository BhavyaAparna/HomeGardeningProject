import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name : string = null;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.name = localStorage.getItem("userFirstName");
  }
  flowers(){
    this.router.navigate(['flowers']);
  }
  cereals(){
    this.router.navigate(['cereals']);
  }
  vagetables(){
    this.router.navigate(['vagetables']);
  }
  gardens(){
    this.router.navigate(['gardens']);
  }

}
