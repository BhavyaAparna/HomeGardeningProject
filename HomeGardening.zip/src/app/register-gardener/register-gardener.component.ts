import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-gardener',
  templateUrl: './register-gardener.component.html',
  styleUrls: ['./register-gardener.component.css']
})
export class RegisterGardenerComponent implements OnInit {
  gardener: any;
  constructor(private router: Router,private service: UserService) {
    this.gardener = {gardenerId: '', gardenerFirstName: '', gardenerLastName: '', gardenerPhoneNumber: '', gardenerEmail: '',gardenerPassword: '', gardenerStreet: '', gardenerCity: '', gardenerState: ''};
   }

  ngOnInit(): void {
  }

  registerGardener(){
    this.service.registerGardener(this.gardener).subscribe((result: any) => { console.log(result); } );
    console.log(this.gardener);
    this.router.navigate(['login-gardener']);
  }
}
