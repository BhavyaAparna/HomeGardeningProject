import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterGardenerComponent } from './register-gardener.component';

describe('RegisterGardenerComponent', () => {
  let component: RegisterGardenerComponent;
  let fixture: ComponentFixture<RegisterGardenerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterGardenerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterGardenerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
