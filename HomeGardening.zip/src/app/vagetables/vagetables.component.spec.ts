import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VagetablesComponent } from './vagetables.component';

describe('VagetablesComponent', () => {
  let component: VagetablesComponent;
  let fixture: ComponentFixture<VagetablesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VagetablesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VagetablesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
