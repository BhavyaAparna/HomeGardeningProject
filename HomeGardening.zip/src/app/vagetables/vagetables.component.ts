import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vagetables',
  templateUrl: './vagetables.component.html',
  styleUrls: ['./vagetables.component.css']
})
export class VagetablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
