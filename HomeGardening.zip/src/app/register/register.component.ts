import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: any;
  constructor(private router: Router,private service: UserService) {
    this.user = {userId: '', userFirstName: '', userLastName: '', userPhoneNumber: '', userEmail: '',userPassword: '', userStreet: '', userCity: '', userState: ''};
   }

  ngOnInit(): void {
  }
  register(): void {
    this.service.registerUser(this.user).subscribe((result: any) => { console.log(result); } );
    console.log(this.user);
    this.router.navigate(['login']);
  }
}
