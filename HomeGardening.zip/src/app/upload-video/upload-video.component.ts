import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';

@Component({
  selector: 'app-upload-video',
  templateUrl: './upload-video.component.html',
  styleUrls: ['./upload-video.component.css']
})
export class UploadVideoComponent implements OnInit {

  videoUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private service: UserService) {
  }
  ngOnInit(): void {
  }
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.videoUrl = event.target.result;
    };
  }
  OnSubmit(videoForm: any) {
    console.log(videoForm);
    this.service.postFile1(videoForm, this.fileToUpload).subscribe (
      data => {
        console.log('done');
      }
    );
    alert("Video Uploaded Successfully");
  }

}
