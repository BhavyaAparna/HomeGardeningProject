import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cereals',
  templateUrl: './cereals.component.html',
  styleUrls: ['./cereals.component.css']
})
export class CerealsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
