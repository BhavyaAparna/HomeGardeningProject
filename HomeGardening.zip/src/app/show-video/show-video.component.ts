import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';
@Component({
  selector: 'app-show-video',
  templateUrl: './show-video.component.html',
  styleUrls: ['./show-video.component.css']
})
export class ShowVideoComponent implements OnInit {
  items: any;
  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.service.getItemVideos().subscribe( (result: any) => {console.log(result); this.items = result; });
  } 


}
