import { Component, OnInit } from '@angular/core';
import { UserService } from './../user.service';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.css']

})
export class UploadImageComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private service: UserService) {
   // this.imageUrl = '/assets/images/flowers.jpg';
  }

  ngOnInit() {
  }

  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.service.postFile(imageForm, this.fileToUpload).subscribe (
      data => {
        console.log('done');
       // this.imageUrl = '/assets/images/flowers.jpg';
      }
    );
    alert("Image Uploaded Successfully");
  }


  // handleFileInput(file: FileList) {
  //   this.fileToUpload = file.item(0);

  //   // Show image preview
  //   this.reader = new FileReader();
  //   this.reader.readAsDataURL(this.fileToUpload);
  //   this.reader.onload = (event: any) => {
  //     this.imageUrl = event.target.result;
  //   };
  // }

  // OnSubmit(imageForm: any) {
  //  this.service.postFile(imageForm, this.fileToUpload).subscribe(
  //    data => {
  //      console.log('done');
  //      this.imageUrl = '/assets/image/default.png';
  //    }
  //  );
  // }
}
