import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginGardenerComponent } from './login-gardener.component';

describe('LoginGardenerComponent', () => {
  let component: LoginGardenerComponent;
  let fixture: ComponentFixture<LoginGardenerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginGardenerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginGardenerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
