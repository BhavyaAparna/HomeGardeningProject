import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './../user.service';

@Component({
  selector: 'app-login-gardener',
  templateUrl: './login-gardener.component.html',
  styleUrls: ['./login-gardener.component.css']
})
export class LoginGardenerComponent implements OnInit {
  gardener: any;
  data : any;
  name: any;
  constructor(private router: Router, private service: UserService) {
    this.gardener = {gardenerEmail: '', gardenerPassword: ''};
  }

  ngOnInit(): void {
  }

  loginGardenerSubmit(loginForm: any): void {

    this.service.getGardenerByUserPass(this.gardener.gardenerEmail,this.gardener.gardenerPassword).subscribe((data: any) => {console.log(data); if(data == null){ 
      alert("Invalid Credentials");
    }
    else{
      alert("Valid Credentials")
      this.name = data.gardenerFirstName;
      localStorage.setItem('gardenerFirstName',this.name)
      this.router.navigate(['home']);
    }
    });
    console.log(loginForm);
  }

}
