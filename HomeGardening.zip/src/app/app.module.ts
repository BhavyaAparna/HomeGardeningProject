import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './auth.guard';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { FlowersComponent } from './flowers/flowers.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { ShowImageComponent } from './show-image/show-image.component';
import { UploadVideoComponent } from './upload-video/upload-video.component';
import { ShowVideoComponent } from './show-video/show-video.component';
import { HeaderHomeComponent } from './header-home/header-home.component';
import { CerealsComponent } from './cereals/cereals.component';
import { GardensComponent } from './gardens/gardens.component';
import { VagetablesComponent } from './vagetables/vagetables.component';
import { LoginGardenerComponent } from './login-gardener/login-gardener.component';
import { RegisterGardenerComponent } from './register-gardener/register-gardener.component';
import { ContactGardenerComponent } from './contact-gardener/contact-gardener.component';
import { BookingComponent } from './booking/booking.component';
const appRoot: Routes = [{path: '', component: LoginComponent},
                         {path: 'login', component: LoginComponent},
                         {path: 'home', component: HomeComponent},
                        {path: 'register', component: RegisterComponent},
                        {path: 'flowers', component: FlowersComponent},
                        {path: 'upload-image', component: UploadImageComponent},
                        {path: 'show-image', component: ShowImageComponent},
                        {path: 'upload-video', component: UploadVideoComponent},
                        {path: 'show-video', component: ShowVideoComponent},
                        {path: 'cereals', component: CerealsComponent},
                        {path: 'gardens', component: GardensComponent},
                        {path: 'vagetables', component: VagetablesComponent},
                        {path: 'login-gardener', component: LoginGardenerComponent},
                        {path: 'register-gardener', component: RegisterGardenerComponent},
                        {path: 'contact-gardener', component: ContactGardenerComponent},
                        {path: 'booking', component: BookingComponent}
                        
                        
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    HomeComponent,
    FlowersComponent,
    UploadImageComponent,
    ShowImageComponent,
    UploadVideoComponent,
    ShowVideoComponent,
    HeaderHomeComponent,
    CerealsComponent,
    GardensComponent,
    VagetablesComponent,
    LoginGardenerComponent,
    RegisterGardenerComponent,
    ContactGardenerComponent,
    BookingComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(appRoot)
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
